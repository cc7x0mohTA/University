mapa = {}

for i in range(1, 35) : mapa[i] = 0.0

for i in range(1, 16):	
	plik = open('a' + str(i) + ".txt")
	try:
		tekst = plik.read()
		L = tekst.split("\n")
	
		for line in L :
			S = line.split(" ")
			a = int(S[0])
			b = float(S[1])
			mapa[a] += b
	finally:
		plik.close()


for i in range(1,35): mapa[i] /= 15

for i in range(1,35):
	print(str(i) + " " + str(mapa[i]))
